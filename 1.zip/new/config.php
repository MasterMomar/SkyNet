<?php
$host     = "localhost"; // Database Host
$user     = "momarmer525628"; // Database Username
$password = "vIn~L~tEq=rfahx~RlB5L?bpuJWg+?F0"; // Database's user Password
$database = "momarmer525628"; // Database Name
$prefix   = "<db_prefix>"; // Database Prefix for the script tables

$mysqli = new mysqli($host, $user, $password, $database);

// Checking Connection
if ($mysqli->connect_errno) {
    echo "Failed to connect to MySQL: " . $mysqli->connect_error;
    exit();
}

$mysqli->set_charset("utf8mb4");

$site_url             = "http://vpnskynet.com";
$projectsecurity_path = "http://vpnskynet.com/vpn";


//start session on web page
//session_start();

//config.php

//Include Google Client Library for PHP autoload file
require_once 'vendor/autoload.php';

//Make object of Google API Client for call Google API
$google_client = new Google_Client();

//Set the OAuth 2.0 Client ID
$google_client->setClientId('95046956766-mcpvp4l00k8e6erlc65kit7egd0immp7.apps.googleusercontent.com');

//Set the OAuth 2.0 Client Secret key
$google_client->setClientSecret('ucuf1mVJsMdAThZViKxCZYbz');

//Set the OAuth 2.0 Redirect URI
$google_client->setRedirectUri('http://localhost/vpn/index.php');

// to get the email and profile 
$google_client->addScope('email');

$google_client->addScope('profile');



if (!session_id())
{
    session_start();
}

// Call Facebook API

$facebook = new \Facebook\Facebook([
  'app_id'      => '921130358246916',
  'app_secret'     => '8d382dc63a190925664594ef090b8a78',
  'default_graph_version'  => 'v2.10'
]);

?>
