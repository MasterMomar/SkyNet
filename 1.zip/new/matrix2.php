<?php

require 'matrix.php';

$matrix = new Matrix();
$matrix->enter();
